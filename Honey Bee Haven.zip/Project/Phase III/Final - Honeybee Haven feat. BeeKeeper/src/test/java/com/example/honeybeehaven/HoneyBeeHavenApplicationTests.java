package com.example.honeybeehaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoneyBeeHavenApplicationTests {

    @Test
    void contextLoads() {
    }

}
