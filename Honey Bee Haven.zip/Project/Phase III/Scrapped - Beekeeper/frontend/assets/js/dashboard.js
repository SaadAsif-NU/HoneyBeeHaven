document.getElementById("adminName").textContent =
  localStorage.getItem("adminName");

document.getElementById("logoutAdmin").addEventListener("click", function () {
  localStorage.removeItem("adminName");
  localStorage.removeItem("adminEmail");
});
