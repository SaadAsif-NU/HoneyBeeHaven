const baseUrl = "http://localhost:5000/beekeper/";
var email, password;
document.addEventListener("DOMContentLoaded", function () {
  var email = document.getElementById("emailInput");
  var password = document.getElementById("passwordInput");
  var loginButton = document.getElementById("loginButton");
  loginButton.addEventListener("click", loginFunction);
});

var loginFunction = function () {
  email = emailInput.value;
  password = passwordInput.value;
  if (email.trim() === "" || password.trim() === "") {
    return;
  }
  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return;
  }
  alert(email + password);
  loginUser();
  return false;
};

let loginUser = async () => {
  localStorage.setItem("adminEmail", email);
  localStorage.setItem("adminName", "Alfred Wilkins");
  window.location.href = "./admin/dashboard.html";

  fetch(baseUrl + "admin/login", {
    method: "POST",
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
    body: JSON.stringify({
      email: email,
      password: password,
    }),
  }).then((res) =>
    res.json().then(function (data) {
      if (data.success == true) {
        localStorage.setItem("adminEmail", data.email);
        localStorage.setItem("adminName", data.name);
        window.location.href = "./admin/dashboard.html";
      }
    })
  );
};

document
  .getElementById("loginForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    loginFunction();
  });
