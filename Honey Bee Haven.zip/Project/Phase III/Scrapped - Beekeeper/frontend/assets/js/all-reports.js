var newReportRows = "";
var deleteReportID = "";
const baseUrl = "http://localhost:5000/beekeeper/all-reports/";
function addBounceClass(event) {
  event.classList.add("fa-bounce");
}

function removeBounceClass(event) {
  event.classList.remove("fa-bounce");
}

getInfo();

async function getInfo() {
  fetch(baseUrl, {
    method: "GET",
  }).then((res) =>
    res.json().then(function (data) {
      //console.log(res.status);
      //console.log(JSON.stringify(data.materialList[0]._id));
      //console.log(JSON.stringify(data.materialList[0].name));
      //console.log(JSON.stringify(data.materialList[0].stock));
      //console.log(JSON.stringify(data.materialList[0].price));
      /* for (var i = 0; i < data.materialList.length; i++) {
        var finalName = sliceString(JSON.stringify(data.materialList[i].name));
        var finalObjID = sliceString(JSON.stringify(data.materialList[i]._id));

        var x = createMaterialRow(
          finalObjID,
          finalName,
          JSON.stringify(data.materialList[i].stock),
          JSON.stringify(data.materialList[i].price)
        );
        var newText = $("#table-body").html() + x;
        $("#table-body").html(newText);
      }*/
    })
  );
}

for (var i = 0; i < 5; i++) {
  newReportRows =
    newReportRows +
    createReportRow(
      "AA-145-BX",
      "123-AA",
      "BB-1266",
      "Lying",
      "RR-WX09",
      "Man was caught lying"
    );
}

$("#table-body").html(newReportRows);

function createReportRow(
  reportID,
  complainerID,
  complaineeID,
  reason,
  reviewID,
  comment
) {
  return (
    `<tr>
  <td>` +
    reportID +
    `</td>
  <td>` +
    complainerID +
    `</td>
  <td>` +
    complaineeID +
    `</td>
  <td>` +
    reason +
    `</td>
  <td>` +
    reviewID +
    `</td>
  <td>` +
    comment +
    `</td>
  <td>
  <a class="edit" title="Edit" ><i class="material-icons" style="color:green;">&#xE254;</i></a>
  <a class="delete" title="Delete" data-target="#delete_asset" data-toggle="modal"><i id="deleteTrashCanIcon" onmouseover="addBounceClass(this)" onmouseout="removeBounceClass(this)" class="material-icons" style="color:red;">&#xE872;</i></a>
  </td>
</tr>`
  );
}

let deletePromise = null;

function openDeleteModal() {
  $("#delete_asset").modal("show");
  deletePromise = new Promise((resolve, reject) => {
    $("#delete-dat").click(() => {
      resolve(true);
      location.reload();
    });
    $("#close-dat, .close").click(() => {
      resolve(false);
      location.reload();
    });
  });
}

async function model_delete() {
  const userConfirmed = await openDeleteModal();
  if (userConfirmed) {
    $("#delete_asset").hide();
  } else {
    $("#delete_asset").hide();
  }
}

$(document).on("click", ".delete", function () {
  deleteData(this);
  model_delete();
});

function deleteData(linkElement) {
  const row = $(linkElement).closest("tr");
  const id = row.find("td:eq(0)").text();
  deleteReportID = id;
  alert("About to send req to delete report of Id: " + id);
}

async function deleteInfo() {
  var finalURL = baseUrl + deleteReportID;
  fetch(finalURL, {
    method: "DELETE",
  }).then((res) =>
    res.json().then(function (data) {
      console.log(data);
    })
  );
  alert("Sent req to delete report of Id: " + deleteReportID);
}

document.getElementById("logoutAdmin").addEventListener("click", function () {
  localStorage.removeItem("adminName");
  localStorage.removeItem("adminEmail");
});
