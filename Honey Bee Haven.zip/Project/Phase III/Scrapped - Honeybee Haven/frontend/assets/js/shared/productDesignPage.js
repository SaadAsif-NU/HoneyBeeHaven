let rating = 0;
let quantity = 0;

function reviewform() {
  let form = document.getElementsByClassName("review-form")[0];
  form.style.display = "block";
  form.innerHTML = `  <div>
                        <h6>Write a Review</h6>
                        <h6>Review Title</h6>
                        <input type="text" name="heading" placeholder="Enter review heading"></input>
                        <h6>Rating</h6>
                        <div class="rating-box">
                            <div class="stars">
                                <i id="s1" class="fa fa-star"></i>
                                <i id="s2" class="fa fa-star"></i> 
                                <i id="s3" class="fa fa-star"></i> 
                                <i id="s4" class="fa fa-star"></i> 
                                <i id="s5" class="fa fa-star"></i> 
                            </div>
                        </div>
                        <h6>Body of review</h6>
                        <textarea name="desc" placeholder="Enter your review here"></textarea>
                        <div style="display: flex; justify-content: flex-end;">
                            <button onclick="submitrev()">Submit Review</button>
                        </div>
                        <div>
                        `;

  const stars = document.querySelectorAll(".stars i");

  // ---- ---- Stars ---- ---- //
  stars.forEach((star, index1) => {
    star.addEventListener("click", (e) => {
      stars.forEach((star, index2) => {
        // ---- ---- Active Star ---- ---- //
        index1 >= index2
          ? star.classList.add("active")
          : star.classList.remove("active");
      });
      console.log(e.target.id);
      rating = e.target.id;
    });
  });
}

function submitrev() {
  let val1 = document.getElementsByName("heading")[0].value;
  let val2 = document.getElementsByName("desc")[0].value;
  console.log(val1);
  console.log(rating);
  console.log(val2);
}

function subtractQuantity() {
  if (quantity > 1) {
    quantity--;
    document.getElementById("quantityToOrder").placeholder = quantity;
  }
}

function addQuantity() {
  if (quantity + 1 <= productQuantityInStock) {
    quantity++;
    document.getElementById("quantityToOrder").placeholder = quantity;
  }
}

function generateRatingTags(rating) {
  var stars = "",
    i = 0;
  for (i = 1; i <= rating; i++) {
    stars += `<i class="fa fa-star"></i>`;
  }
  i = i - 1;
  if (rating - i > 0) {
    stars += `<i class="fas fa-star-half-alt"></i>`;
  }

  return (
    stars +
    `<span class="ms-1">
    ` +
    rating +
    `</span>`
  );
}

var productQuantityInStock = 10; // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL
var productHeading = "product Heading Goes Here"; // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL AND SERVICE
var productRating = 3.5; // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL AND SERVICE
var productPrice = 100; // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL AND SERVICE
var productDescription = // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL AND SERVICE
  "Modern look and quality demo item is a streetwear-inspired collection that continues to break away from the conventions of mainstream fashion. Made in Italy, these black and brown clothing low-top shirts for men.";
var productType = "Machinery Chemical Service"; // THIS IS GENERIC ATTRIBUTE FOR BOTH MACHINE AND CHEMICAL AND SERVICE

//VARIABLES FOR INFORMATION OF MACHINE
var machineType = "Tractor TubeWell Motor ";
var machineDimension = "3x3x3";
var machineWeight = "70 kg";
var machinePowerSource = "Oil";
var machineWarranty = "3 years";

//VARIABLES FOR INFORMATION OF CHEMICAL
var metricSystem = "litre kg pound inches";
var chemicalType = "Liquid Solid Gas";
var expiryDate = "20th October 2023";
var hazardLevel = "Dangerous";

//VARIABLES FOR INFORMATION OF SERVICE
var baseCharges = 12;

document.addEventListener("DOMContentLoaded", function () {
  if (window.location.search === "?machine") {
    let form = document.getElementsByClassName("py-5")[0];
    form.innerHTML =
      `<div class="container">
        <div class="row gx-5">
          <aside class="col-lg-6">
            <div class="border rounded-4 mb-3 d-flex justify-content-center">
                <img style="max-width: 100%; max-height: 100vh; margin: auto;" class="rounded-4 fit" src="https://bootstrap-ecommerce.com/bootstrap5-ecommerce/images/items/detail1/big.webp" />
            </div>
          </aside>
          <main class="col-lg-6">
            <div class="ps-lg-3">
              <h4 id="businessHeadingTag" class="title text-dark">
                ` +
      productHeading +
      `
              </h4>
              <div class="d-flex flex-row my-3">
                <div class="text-warning mb-1 me-2">` +
      generateRatingTags(productRating) +
      ` </div>
                <span class="text-muted"><i class="fas fa-shopping-basket fa-sm mx-1"></i>` +
      productQuantityInStock +
      `</span>
                <span class="text-success ms-2">In stock</span>
              </div>
    
              <div class="mb-3">
                <span class="h5">Rs. ` +
      productPrice +
      `</span> 
              </div>
    
              <p>
                ` +
      productDescription +
      `
              </p>
              <div class="row">
                <dt class="col-3">Item</dt>
                <dd class="col-9">` +
      productType +
      `</dd>
    
                <dt class="col-3">Machine Type</dt>
                <dd class="col-9">` +
      machineType +
      `</dd>

                <dt class="col-3">Dimensions</dt>
                <dd class="col-9">` +
      machineDimension +
      `</dd>
                <dt class="col-3">Weight</dt>
                <dd class="col-9">` +
      machineWeight +
      `</dd>

                <dt class="col-3">Power Source</dt>
                <dd class="col-9">` +
      machinePowerSource +
      `</dd>

                <dt class="col-3">Warranty</dt>
                <dd class="col-9">` +
      machineWarranty +
      `</dd>
              </div>
              <hr />
    
        
                <!-- col.// -->
                <div class="col-md-4 col-6 mb-3">
                  <label class="mb-2 d-block">Quantity</label>
                  <div class="input-group mb-3" style="width: 170px;">
                    <button onclick="subtractQuantity()" class="btn btn-white border border-secondary px-3" type="button" id="button-addon1" data-mdb-ripple-color="dark">
                      <i class="fas fa-minus"></i>
                    </button>
                    <input style="background-color:white;"  disabled id="quantityToOrder" type="text" class="form-control text-center border border-secondary" placeholder="` +
      quantity +
      `" aria-label="Example text with button addon" aria-describedby="button-addon1" />
                    <button onclick="addQuantity()" class="btn btn-white border border-secondary px-3"  type="button" id="button-addon2" data-mdb-ripple-color="dark">
                      <i class="fas fa-plus"></i>
                    </button>
                  </div>
                </div>
              </div>
              <a href="#" class="btn btn-warning shadow-0"> Buy now </a>
            </div>
          </main>
        </div>
      </div>`;
  }
  if (window.location.search === "?chemical") {
    let form = document.getElementsByClassName("py-5")[0];
    form.innerHTML =
      `<div class="container">
        <div class="row gx-5">
          <aside class="col-lg-6">
            <div class="border rounded-4 mb-3 d-flex justify-content-center">
                <img style="max-width: 100%; max-height: 100vh; margin: auto;" class="rounded-4 fit" src="https://bootstrap-ecommerce.com/bootstrap5-ecommerce/images/items/detail1/big.webp" />
            </div>
          </aside>
          <main class="col-lg-6">
            <div class="ps-lg-3">
              <h4 class="title text-dark">
              ` +
      productHeading +
      `
              </h4>
              <div class="d-flex flex-row my-3">
                <div class="text-warning mb-1 me-2">` +
      generateRatingTags(productRating) +
      `
                </div>
                <span class="text-muted"><i class="fas fa-shopping-basket fa-sm mx-1"></i>` +
      productQuantityInStock +
      `</span>
                <span class="text-success ms-2">In stock</span>
              </div>
    
              <div class="mb-3">
                <span class="h5">Rs. ` +
      productPrice +
      `</span>
              </div>
              <p>
              ` +
      productDescription +
      `
              </p>
    
              <div class="row">
                <dt class="col-3">Type</dt>
                <dd class="col-9">` +
      productType +
      `</dd>
    
                <dt class="col-3">Metric System</dt>
                <dd class="col-9">` +
      metricSystem +
      `</dd>

                <dt class="col-3">Chemical Type</dt>
                <dd class="col-9">` +
      chemicalType +
      `</dd>

      <dt class="col-3">Expiry Date</dt>
                <dd class="col-9">` +
      expiryDate +
      `</dd>
                <dt class="col-3">Hazard</dt>
                <dd class="col-9">` +
      hazardLevel +
      `</dd>
              </div>
              <hr />
    
        
                <!-- col.// -->
                <div class="col-md-4 col-6 mb-3">
                <label class="mb-2 d-block">Quantity</label>
                <div class="input-group mb-3" style="width: 170px;">
                  <button onclick="subtractQuantity()" class="btn btn-white border border-secondary px-3" type="button" id="button-addon1" data-mdb-ripple-color="dark">
                    <i class="fas fa-minus"></i>
                  </button>
                  <input style="background-color:white;"  disabled id="quantityToOrder" type="text" class="form-control text-center border border-secondary" placeholder="` +
      quantity +
      `" aria-label="Example text with button addon" aria-describedby="button-addon1" />
                  <button onclick="addQuantity()" class="btn btn-white border border-secondary px-3"  type="button" id="button-addon2" data-mdb-ripple-color="dark">
                    <i class="fas fa-plus"></i>
                  </button>
                </div>
              </div>
            </div>
              <a href="#" class="btn btn-warning shadow-0"> Buy now </a>
            </div>
          </main>
        </div>
      </div>`;
  }
  if (window.location.search === "?service") {
    let form = document.getElementsByClassName("py-5")[0];
    form.innerHTML =
      `<div class="container">
        <div class="row gx-5">
          <aside class="col-lg-6">
            <div class="border rounded-4 mb-3 d-flex justify-content-center">
                <img style="max-width: 100%; max-height: 100vh; margin: auto;" class="rounded-4 fit" src="https://bootstrap-ecommerce.com/bootstrap5-ecommerce/images/items/detail1/big.webp" />
            </div>
          </aside>
          <main class="col-lg-6">
            <div class="ps-lg-3">
              <h4 class="title text-dark">              ` +
      productHeading +
      `
              </h4>
              <div class="d-flex flex-row my-3">
                <div class="text-warning mb-1 me-2">
                ` +
      generateRatingTags(productRating) +
      `
                </div>
              </div>
    
              <div class="mb-3">
                <span class="h5">Rs. ` +
      productPrice +
      `</span> 
      <span class="text-muted">/per hr</span>
              </div>
    
              <p>
              ` +
      productDescription +
      `
              </p>
    
              <div class="row">
                <dt class="col-3">Type</dt>
                <dd class="col-9">` +
      productType +
      `</dd>
    
                <dt class="col-3">Base Charges</dt>
                <dd class="col-9">Rs. ` +
      baseCharges +
      `</dd>

              </div>
              <hr />
              <a href="#" class="btn btn-warning shadow-0"> Buy now </a>
            </div>
          </main>
        </div>
      </div>`;
  }
});
