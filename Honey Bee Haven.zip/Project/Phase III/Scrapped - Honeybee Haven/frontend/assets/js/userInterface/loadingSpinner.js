/*export var startLoadingSpinner = () => {
  var loader = document.getElementById("loadingSpinner");
  loader.classList.add("loader");
};
export var stopLoadingSpinner = () => {
  var loader = document.getElementById("loadingSpinner");
  loader.classList.add("loader-hidden");
  loader.classList.remove("loader-hidden");
  loader.classList.remove("loader");
};*/

window.addEventListener("load", () => {
  const loader = document.querySelector(".loader");

  loader.classList.add("loader-hidden");

  loader.addEventListener("transitionend", () => {
    document.body.removeChild("loader");
  });
});
