// business about section
var businessProfileImagePath = "blog-2.jpg";
var businessId = "AX-159-998";
var businessName = "Millat Tractors";
var businessOwnerUsername = "Alex Fran";
var businessAddress = "Milaad Street";
var businessEmail = "millat.tractors_PK@gmail.com.pk";
var businessContactInformation = "0309-6085528";
var businessRating = "3.5";
// Blogs and News Section
var blogsAndNewsImagesPath = [
  "shared/p1.png",
  "shared/pic2.png",
  "shared/vegetable.png",
];
var blogsAndNewsDate = ["19th Oct, 19", "19th Oct, 19", "19th Oct, 19"];
var blogsAndNewsHeading = [
  "Quick guide on business with friends.",
  "Become more money-minded",
  "Quick guide on business with friends.",
];
var blogsAndNewsArticleTextTruncated = [
  "There is now an abundance of readable dummy texts. These are usually used when a text is required purely to fill a space.",
  "There is now an abundance of readable dummy texts. These are usually used when a text is required purely to fill a space.",
  "There is now an abundance of readable dummy texts. These are usually used when a text is required purely to fill a space.",
];
var blogsAndNewsAuthorName = ["Lisa Marvel", "Joya Aafri", "Martin Sobhe"];
var totalBlogsAndNewsCount = 3;
function generateAboutSection() {
  return (
    `<div class="container bootstrap snippets bootdey">
    <div class="panel-body inf-content">
        <div class="row">
            <div class="col-md-3">
                <img alt="business profile image" id="businessProfileImage" style="width:300px;" src="../assets/images/business/` +
    businessProfileImagePath +
    `"> 
                <button id="editProfileButton" href="" class="btn btn-lg  mx-5 my-1" >Edit Profile</button>
            </div>
            <div class="col-md-6">
                <h1 id="headerTitle">About</h1><br>
                <div class="table-responsive">
                <table class="table table-user-information">
                    <tbody>
                        <tr>        
                            <td>
                                <strong>
  
                                    <span class="glyphicon glyphicon-asterisk text-primary"></span>
                                   Business Identification                                             
                                </strong>
                            </td>
                            <td class="text-primary">
                               ` +
    businessId +
    `   
                            </td>
                        </tr>
                        <tr>    
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-user  text-primary"></span>    
                                    Bussiness Name                                                
                                </strong>
                            </td>
                            <td class="text-primary">
                                ` +
    businessName +
    `     
                            </td>
                        </tr>
    
                        <tr>        
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-bookmark text-primary"></span> 
                                    Username                                                
                                </strong>
                            </td>
                            <td class="text-primary">
                               ` +
    businessOwnerUsername +
    `
                            </td>
                        </tr>
    
    
                        <tr>        
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-eye-open text-primary"></span> 
                                    Address                                                
                                </strong>
                            </td>
                            <td class="text-primary">
                                ` +
    businessAddress +
    `
                            </td>
                        </tr>
                        <tr>        
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-envelope text-primary"></span> 
                                    Email                                                
                                </strong>
                            </td>
                            <td class="text-primary">
                                ` +
    businessEmail +
    `
                            </td>
                        </tr>
                        <tr>        
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-calendar text-primary"></span>
                                    Contact Information                                                
                                </strong>
                            </td>
                            <td class="text-primary">
                                ` +
    businessContactInformation +
    `
                            </td>
                        </tr>
                        <tr>        
                            <td>
                                <strong>
                                    <span class="glyphicon glyphicon-calendar text-primary"></span>
                                    Rating                                              
                                </strong>
                            </td>
                            <td class="text-primary">
                                 ` +
    businessRating +
    `
                            </td>
                        </tr>                                    
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
    </div>`
  );
}

function generateBlogsAndNewsSection() {
  var HTMLtext = ``;
  for (var i = 0; i < totalBlogsAndNewsCount; i++) {
    HTMLtext =
      HTMLtext +
      `   <div class="col-lg-4 col-md-6 mt-4 pt-2">
    <div class="blog-post rounded border">
        <div class="blog-img d-block overflow-hidden position-relative">
            <img src="../assets/images/` +
      blogsAndNewsImagesPath[i] +
      `" class="img-fluid rounded-top" alt="">
            <div class="overlay rounded-top bg-dark"></div>
            <div class="post-meta">
                <a href="javascript:void(0)" class="text-light read-more">Read More <i class="mdi mdi-chevron-right"></i></a>
            </div>
        </div>
        <div class="content p-3">
            <small class="text-muted p float-right">` +
      blogsAndNewsDate[i] +
      `</small>
            <h4 class="mt-2"><a href="javascript:void(0)" class="text-dark title">` +
      blogsAndNewsHeading[i] +
      `</a></h4>
            <p class="text-muted mt-2">` +
      blogsAndNewsArticleTextTruncated[i] +
      `</p>
            <div class="pt-3 mt-3 border-top d-flex">
              <div class="author mt-2">
                    <h6 class="mb-0"><a href="javascript:void(0)" class="text-dark name"> ` +
      blogsAndNewsAuthorName[i] +
      `</a></h6>
                </div>
            </div>
        </div>
    </div>
</div>`;
  }
  return HTMLtext;
}

document.addEventListener("DOMContentLoaded", function () {
  let form = document.getElementById("aboutSectionBusiness");
  form.innerHTML = generateAboutSection();

  let form2 = document.getElementById("blogsAndNewsSection");
  console.log(form2);
  form2.innerHTML = generateBlogsAndNewsSection();
});
