var newProuctCards = "";
var totalProductCards = 11;

document.addEventListener("DOMContentLoaded", function () {
  let form = document.getElementById("displayProductsPage");
  form.innerHTML = generateProductSection();
});

var generateProductSection = () => {
  for (var i = 0, k = totalProductCards, x = 0; i < totalProductCards; ) {
    newProuctCards = newProuctCards + `<div class="row">`;
    if (k >= 4) {
      x = 4;
      k = k - 4;
    } else {
      x = totalProductCards % 4;
      k = 0;
    }
    for (var j = 0; j < x; j++, i++) {
      newProuctCards =
        newProuctCards +
        createProductCard(
          "MachineChemicalService",
          "business/laptop.PNG",
          "Product TITLE",
          "AXSA",
          6,
          3.5
        );
    }
    newProuctCards = newProuctCards + `</div>`;
  }
  return newProuctCards;
};

var createProductCard = (
  productType,
  productImagePath,
  productTitle,
  productID,
  productStock,
  productRating
) => {
  return (
    `<div class="col-md-12 col-lg-3 mb-4 mb-lg-0">
    <div class="card">
      <div class="d-flex justify-content-between p-2">
        <p class="lead mb-0">` +
    productType +
    `</p>
        <P>
        <a class="delete" title="Delete" data-target="#delete_asset" data-toggle="modal"><i class="fa-solid fa-pen" id="editPenIcon" onmouseover="addShakeClass(this)" onclick="editIconClicked(this)" onmouseout="removeShakeClass(this)" class="fa-solid fa-trash" ></i></a>
        <a class="delete" title="Delete" data-target="#delete_asset" data-toggle="modal"><i id="deleteTrashCanIcon" onmouseover="addBounceClass(this)" onclick="deleteIconClicked(this)" onmouseout="removeBounceClass(this)" class="fa-solid fa-trash"></i></a>
        </P>
      </div>
      <hr>
      <img src="../assets/images/` +
    productImagePath +
    `"
        class="card-img-top" />
      <hr>
      <div class="card-body">
        <div class="d-flex justify-content-between mb-3">
          <h5 class="mb-0">` +
    productTitle +
    `</h5>
          <h5 class="text-dark mb-0">Rs. 999</h5>
        </div>
         <p>Product ID: <span id="productId">` +
    productID +
    `</span> </p>
        <div class="d-flex justify-content-between mb-2">
          <p class="text-muted mb-0">Stock: <span class="fw-bold">` +
    productStock +
    `</span></p>
          <div class="ms-auto text-warning"> 
             <span style="color: black;">` +
    productRating +
    ` </span><i id="reviewStarIcon" onmouseover="addFlipClass(this)" onmouseout="removeFlipClass(this)"   class="fa fa-star"></i> 
          </div>
        </div>
      </div>
    </div>
  </div>`
  );
};

function addBounceClass(event) {
  event.classList.add("fa-bounce");
}

function removeBounceClass(event) {
  event.classList.remove("fa-bounce");
}

function addShakeClass(event) {
  event.classList.add("fa-shake");
}

function removeShakeClass(event) {
  event.classList.remove("fa-shake");
}

function addFlipClass(event) {
  event.classList.add("fa-flip");
}

function removeFlipClass(event) {
  event.classList.remove("fa-flip");
}

function deleteIconClicked(event) {
  alert("delete icon clicked");
}

function editIconClicked(event) {
  alert("edit icon clicked");
}
