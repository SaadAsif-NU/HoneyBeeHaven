/*import {
  startLoadingSpinner,
  stopLoadingSpinner,
} from "../userInterface/loadingSpinner.js";
*/
var dispatchOrderID = "";
var totalOrders = 25;
var newOrderRows = "";
const baseUrl = " ";

//getOrders();

var getOrders = () => {
  fetch(baseUrl, {
    method: "GET",
  }).then((res) =>
    res.json().then(function (data) {
      //console.log(res.status);
      //console.log(JSON.stringify(data.materialList[0]._id));
      //console.log(JSON.stringify(data.materialList[0].name));
      //console.log(JSON.stringify(data.materialList[0].stock));
      //console.log(JSON.stringify(data.materialList[0].price));
      /* for (var i = 0; i < data.materialList.length; i++) {
            var finalName = sliceString(JSON.stringify(data.materialList[i].name));
            var finalObjID = sliceString(JSON.stringify(data.materialList[i]._id));
    
            var x = createMaterialRow(
              finalObjID,
              finalName,
              JSON.stringify(data.materialList[i].stock),
              JSON.stringify(data.materialList[i].price)
            );
            var newText = $("#table-body").html() + x;
            $("#table-body").html(newText);
          }*/
    })
  );
};
//startLoadingSpinner();
for (var i = 0; i < totalOrders; i++) {
  newOrderRows =
    newOrderRows +
    createOrderPageRow(
      "1",
      "AX-11",
      "AvzSS",
      "Joe Biden",
      "4",
      "100",
      "23-5-2023",
      "FAST-NUCES Faisal Town, Lahore",
      "",
      ""
    );
}
document.getElementById("orderPageTableBody").innerHTML = newOrderRows;
//stopLoadingSpinner();

function createOrderPageRow(
  index,
  orderID,
  itemID,
  clientName,
  itemQuantity,
  OrderCost,
  orderDate,
  shippingAddress,
  dispatchDate,
  deliveryDate
) {
  return (
    `      <tr>
  <td>` +
    index +
    `</td>
  <td>` +
    orderID +
    `</td>
  <td>` +
    itemID +
    `</td>
  <td>` +
    clientName +
    `</td>
  <td>` +
    itemQuantity +
    `</td>
  <td>` +
    OrderCost +
    `</td>
  <td>` +
    orderDate +
    `</td>
  <td>` +
    shippingAddress +
    `</td>
  <td>` +
    dispatchDate +
    `</td>
  <td>` +
    deliveryDate +
    `</td>
  <td>
      <Button id="dispatchOrderButton" onclick="getDispatchRow(this)" class="btn btn-primary delivery-button" data-bs-toggle="modal" data-bs-target="#dispatchModal" >Dispatch Order</Button>
  </td>
</tr>`
  );
}

var dispatchOrder = () => {
  /*var finalURL = baseUrl + deleteReportID;
    fetch(finalURL, {
      method: "DELETE",
    }).then((res) =>
      res.json().then(function (data) {
        console.log(data);
      })
    );*/
  alert("Sent req to dispatch order of Id: " + dispatchOrderID);
  console.log("Sent req to dispatch order of Id: " + dispatchOrderID);
};

function getDispatchRow(event) {
  const row = $(event).closest("tr");
  console.log(row);
  dispatchOrderID = row.find("td:eq(1)").text();
  alert("About to send req to dispatch order of ID: " + dispatchOrderID);
  console.log("About to send req to dispatch order of ID: " + dispatchOrderID);
}
