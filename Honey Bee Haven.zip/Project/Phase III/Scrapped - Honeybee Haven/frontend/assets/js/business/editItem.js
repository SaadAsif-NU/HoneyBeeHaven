const OPENED_FORM_MACHINE = "Machine",
  OPENED_FORM_CHEMICAL = "Chemical",
  OPENED_FORM_SERVICE = "Service";
let openendForm = "";

var itemTitle = ""; // COMMON FOR ALL 3
var itemPrice = ""; // COMMON FOR ALL 3
var itemDescription = ""; // COMMON FOR ALL 3

var itemStock = ""; // COMMON FOR MACHINE AND CHEMICAL

var machineDimensions = "";
var machineWeight = "";
var machineWarranty = "";

var chemicalMetricSystem = "";
var chemicalExpiryDate = "";
var chemicalQuantity = "";

var serviceBaseCharges = "";

document.addEventListener("DOMContentLoaded", function () {
  if (window.location.search === "?machine") {
    let form = document.getElementsByClassName("form-container")[0];
    form.style.padding = "20px";
    form.innerHTML = `<h3>Machine Title</h3>
    <input id="itemTitle" type="text" placeholder="Enter Title" name="mname">
    <h3>Price</h3>
    <input id="itemPrice" type="number" value="0" name="mprice">
    <h3>Machinery Description</h3>
    <textarea id="itemDescription" placeholder="Machine Description" name="mdesc"></textarea>
    <h3>Dimensions</h3>
    <input id="machineDimensions" type="text" value="" name="mdimensions">
    <h3>Weight</h3>
    <input id="machineWeight" type="number" value="0" name="mweight">
    <h3>Warranty (years)</h3>
    <input id="machineWarranty" type="number" value="0" name="mwarr">
    <h3>Stock</h3>
    <input id="quantityInStock" type="number" value="0" name="mquantity">
    <div>
        <button id="editButton">Update</button>
    </div>`;
    updateEditButtonDOM();
    openendForm = OPENED_FORM_MACHINE;
    let butt = document.getElementsByClassName("form-button");

    Array.from(butt).forEach((element) => {
      element.classList.remove("button-active");
    });

    but.classList.add("button-active");
  }
  if (window.location.search === "?chemical") {
    let form = document.getElementsByClassName("form-container")[0];
    form.style.padding = "20px";
    form.innerHTML = `<h3>Chemical Title</h3>
    <input id="itemTitle" type="text" placeholder="Enter Title" name="cname">
    <h3>Price</h3>
    <input id="itemPrice" type="number" value="0" name="cprice">
    <h3>Chemical Description</h3>
    <textarea id="itemDescription" placeholder="Chemical Description" name="cdesc"></textarea>       
    <h3>Metric System</h3>
    <input id="metricSystem" type="text" value="" name="csystem">
    <h3>Expiry Date</h3>
    <input id="expiryDate" type="date" name="cedate">
    <h3>Chemical Quantity</h3>
    <input id="quantity" type="number" value="0" name="cquan">
    <h3>Stock</h3>
    <input id="quantityInStock"type="number" value="0" name="cquantity">
    <div>
         <button id="editButton">Update</button>
    </div>`;
    let butt = document.getElementsByClassName("form-button");
    updateEditButtonDOM();
    openendForm = OPENED_FORM_CHEMICAL;
    Array.from(butt).forEach((element) => {
      element.classList.remove("button-active");
    });

    but.classList.add("button-active");
  }
  if (window.location.search === "?service") {
    let form = document.getElementsByClassName("form-container")[0];
    form.style.padding = "20px";
    form.innerHTML = `<h3>Service Title</h3>
    <input id="itemTitle" type="text" placeholder="Enter Title" name="sname">
    <h3>Price per hour</h3>
    <input id="itemPrice" type="number" value="0" name="sprice">
    <h3>Service Description</h3>
    <textarea id="itemDescription" placeholder="Service Description" name="sdesc"></textarea>
    <h3>Base Charges</h3>         
    <input id="baseCharges" type="number" value="0" name="sbase">
    <div>
    <button id="editButton">Update</button>
    </div>`;
    let butt = document.getElementsByClassName("form-button");

    Array.from(butt).forEach((element) => {
      element.classList.remove("button-active");
    });
    updateEditButtonDOM();
    openendForm = OPENED_FORM_SERVICE;
    but.classList.add("button-active");
  }
});

function updateEditButtonDOM() {
  let createButton = document.getElementById("editButton");
  createButton.addEventListener("click", editButtonPressed);
}

let editButtonPressed = () => {
  if (openendForm === OPENED_FORM_MACHINE) {
    itemTitle = document.getElementById("itemTitle").value;
    itemPrice = document.getElementById("itemPrice").value;
    itemDescription = document.getElementById("itemDescription").value;

    machineDimensions = document.getElementById("machineDimensions").value;

    machineWeight = document.getElementById("machineWeight").value;
    machineWarranty = document.getElementById("machineWarranty").value;
    itemStock = document.getElementById("quantityInStock").value;

    alert(
      "Machine was updated " +
        itemTitle.toString() +
        itemPrice.toString() +
        itemDescription.toString() +
        machineDimensions.toString() +
        machineWeight.toString() +
        machineWarranty.toString() +
        itemStock.toString()
    );
  } else if (openendForm === OPENED_FORM_CHEMICAL) {
    itemTitle = document.getElementById("itemTitle").value;
    itemPrice = document.getElementById("itemPrice").value;
    itemDescription = document.getElementById("itemDescription").value;
    chemicalMetricSystem = document.getElementById("metricSystem").value;
    chemicalExpiryDate = document.getElementById("expiryDate").value;
    chemicalQuantity = document.getElementById("quantity").value;
    itemStock = document.getElementById("quantityInStock").value;
    alert(
      "Chemical was updated " +
        itemTitle.toString() +
        itemPrice.toString() +
        itemDescription.toString() +
        chemicalMetricSystem.toString() +
        chemicalExpiryDate.toString() +
        chemicalQuantity.toString() +
        itemStock.toString()
    );
  } else if (openendForm === OPENED_FORM_SERVICE) {
    itemTitle = document.getElementById("itemTitle").value;
    itemPrice = document.getElementById("itemPrice").value;
    itemDescription = document.getElementById("itemDescription").value;
    serviceBaseCharges = document.getElementById("baseCharges").value;

    alert(
      "Service was updated " +
        itemTitle.toString() +
        itemPrice.toString() +
        itemDescription.toString() +
        serviceBaseCharges.toString()
    );
  }
};
