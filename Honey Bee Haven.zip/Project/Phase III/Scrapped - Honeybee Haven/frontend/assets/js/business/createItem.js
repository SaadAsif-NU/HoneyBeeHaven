const OPENED_FORM_MACHINE = "Machine",
  OPENED_FORM_CHEMICAL = "Chemical",
  OPENED_FORM_SERVICE = "Service";
let openendForm = "";

var itemTitle = ""; // COMMON FOR ALL 3
var itemPrice = ""; // COMMON FOR ALL 3
var itemDescription = ""; // COMMON FOR ALL 3
var itemType = ""; // COMMON FOR ALL 3

var itemStock = ""; // COMMON FOR MACHINE AND CHEMICAL

var machineDimensions = "";
var machineWeight = "";
var machinePowerSource = "";
var machineWarranty = "";

var chemicalMetricSystem = "";
var chemicalExpiryDate = "";
var chemicalQuantity = "";

var serviceBaseCharges = "";

function displayMachine(but) {
  let form = document.getElementsByClassName("form-container")[0];
  form.style.padding = "20px";
  form.innerHTML = `<h3>Machine Title</h3>
        <input type="text" placeholder="Enter Title" name="mname">
        <h3>Price</h3>
        <input type="number" value="0" name="mprice">
        <h3>Machinery Description</h3>
        <textarea placeholder="Machine Description" name="mdesc"></textarea>
        <h3>Machine Type</h3>
        <select name="mtype">
            <option value="default">Select Option</option>
            <option value="volvo">Volvo</option>
            <option value="saab">Saab</option>
            <option value="mercedes">Mercedes</option>
            <option value="audi">Audi</option>
        </select>          
        <h3>Dimensions</h3>
        <input type="text" value="" name="mdimensions">
        <h3>Weight</h3>
        <input type="number" value="0" name="mweight">
        <h3>Power Source</h3>
        <select name="mfuel">
            <option value="default">Select Option</option>
            <option value="deisel">deisel</option>
            <option value="electric">electric</option>
        </select> 
        <h3>Warranty (years)</h3>
        <input type="number" value="0" name="mwarr">
        <h3>Stock</h3>
        <input type="number" value="0" name="mquantity">
        <div>
            <button id="createButton">Create!</button>
        </div>`;

  let butt = document.getElementsByClassName("form-button");

  Array.from(butt).forEach((element) => {
    element.classList.remove("button-active");
  });
  updateCreateButtonDOM();
  openendForm = OPENED_FORM_MACHINE;
  but.classList.add("button-active");
}

function displayChemical(but) {
  let form = document.getElementsByClassName("form-container")[0];
  form.style.padding = "20px";
  form.innerHTML = `<h3>Chemical Title</h3>
    <input type="text" placeholder="Enter Title" name="cname">
    <h3>Price</h3>
    <input type="number" value="0" name="cprice">
    <h3>Chemical Description</h3>
    <textarea placeholder="Chemical Description" name="cdesc"></textarea>
    <h3>Chemical Type</h3>
    <select name="ctype">
        <option value="default">Select Option</option>
        <option value="volvo">Volvo</option>
        <option value="saab">Saab</option>
        <option value="mercedes">Mercedes</option>
        <option value="audi">Audi</option>
    </select>          
    <h3>Metric System</h3>
    <input type="text" value="" name="csystem">
    <h3>Expiry Date</h3>
    <input type="date" name="cedate">
    <h3>Chemical Quantity</h3>
    <input type="number" value="0" name="cquan">
    <h3>Stock</h3>
    <input type="number" value="0" name="cquantity">
    <div>
        <button id="createButton">Create!</button>
    </div>`;
  let butt = document.getElementsByClassName("form-button");

  Array.from(butt).forEach((element) => {
    element.classList.remove("button-active");
  });
  updateCreateButtonDOM();
  openendForm = OPENED_FORM_CHEMICAL;
  but.classList.add("button-active");
}

function displayService(but) {
  let form = document.getElementsByClassName("form-container")[0];
  form.style.padding = "20px";
  form.innerHTML = `<h3>Service Title</h3>
    <input type="text" placeholder="Enter Title" name="sname">
    <h3>Price per hour</h3>
    <input type="number" value="0" name="sprice">
    <h3>Service Description</h3>
    <textarea placeholder="Service Description" name="sdesc"></textarea>
    <h3>Service Type</h3>
    <select name="stype">
        <option value="default">Select Option</option>
        <option value="volvo">Volvo</option>
        <option value="saab">Saab</option>
        <option value="mercedes">Mercedes</option>
        <option value="audi">Audi</option>
    </select> 
    <h3>Base Charges</h3>         
    <input type="number" value="0" name="sbase">
    <div>
    <button id="createButton">Create!</button>
    </div>`;
  let butt = document.getElementsByClassName("form-button");

  Array.from(butt).forEach((element) => {
    element.classList.remove("button-active");
  });
  updateCreateButtonDOM();
  openendForm = OPENED_FORM_SERVICE;
  but.classList.add("button-active");
}

function updateCreateButtonDOM() {
  let createButton = document.getElementById("createButton");
  createButton.addEventListener("click", createButtonPressed);
}

let createButtonPressed = () => {
  if (openendForm === OPENED_FORM_MACHINE) {
    alert("Machine was Created");
  } else if (openendForm === OPENED_FORM_CHEMICAL) {
    alert("Chemical was Created");
  } else if (openendForm === OPENED_FORM_SERVICE) {
    alert("Service was Created");
  }
};
