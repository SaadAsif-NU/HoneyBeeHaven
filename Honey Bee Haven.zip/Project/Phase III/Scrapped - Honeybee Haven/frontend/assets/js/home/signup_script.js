document.addEventListener('DOMContentLoaded', function() {

  // Function to show the notification
  function showNotification(message) {
      const notification = document.createElement('div');
      notification.className = 'notification';
      notification.innerText = message;

      document.body.appendChild(notification);

      setTimeout(() => {
          notification.style.opacity = '0';
          setTimeout(() => {
              notification.remove();
          }, 500); // This timeout should match the transition duration in the CSS
      }, 3000); // Display the notification for 3 seconds
  }



 // Capturing and saving the signup form data
  const signupForm = document.querySelector('.signup-form form');
  signupForm.addEventListener('submit', function(e) {
      e.preventDefault(); 

      const name = signupForm.querySelector('.input-box:nth-child(1) input[type="text"]').value;
      const email = signupForm.querySelector('.input-box:nth-child(2) input[type="text"]').value;
      const password = signupForm.querySelector('.input-box:nth-child(3) input[type="password"]').value;
      const address = signupForm.querySelector('.input-box:nth-child(4) input[type="text"]').value;
      // Variables 'name', 'email', and 'password' now hold the user's signup input.
      // You can now send this data to your backend.

      showNotification('Signup form submitted!');
  });

});