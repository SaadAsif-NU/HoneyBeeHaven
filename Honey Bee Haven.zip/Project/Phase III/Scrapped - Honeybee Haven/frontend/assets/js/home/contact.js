function sendMessage() {
  var name = document.querySelector('input[name="name"]').value;
  var email = document.querySelector('input[name="email"]').value;
  var subject = document.querySelector('input[name="subject"]').value;
  var message = document.querySelector('textarea[name="message"]').value;
  if (
    name.length === 0 ||
    email.length === 0 ||
    subject.length === 0 ||
    message.length === 0
  ) {
    alert("missing Arguments");
  } else {
    alert("messafe received " + name + email + subject + message);
    location.reload();
  }
}
