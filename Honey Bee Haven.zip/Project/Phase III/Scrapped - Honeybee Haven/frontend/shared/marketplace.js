
function hello(e){
 
 console.log("THis is the product iD;:: "+e);

}


document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("apply-filter").addEventListener("change", function () {
        console.log("hello");
        const filterContainer = document.getElementById("filter-container");
        filterContainer.style.display = this.checked ? "flex" : "none";
    });

    const keywordCheckboxes = document.querySelectorAll(".keyword-checkbox");
            keywordCheckboxes.forEach(checkbox => {
                checkbox.addEventListener("change", function () {
                    const selectedKeywords = Array.from(keywordCheckboxes)
                        .filter(checkbox => checkbox.checked)
                        .map(checkbox => checkbox.value);
                    const keywordContainer = document.getElementById("selected-keywords");
                    keywordContainer.innerHTML = "";
                    for (const keyword of selectedKeywords) {
                        const keywordDiv = document.createElement("div");
                        keywordDiv.classList.add("keyword");
                        keywordDiv.innerText = keyword;
                        keywordDiv.setAttribute("data-keyword", keyword);
                        keywordDiv.addEventListener("click", function () {
                            this.remove();
                            document.querySelector(`input[value="${keyword}"]`).checked = false;
                        });
                        keywordContainer.appendChild(keywordDiv);

    }
})}
);
});
