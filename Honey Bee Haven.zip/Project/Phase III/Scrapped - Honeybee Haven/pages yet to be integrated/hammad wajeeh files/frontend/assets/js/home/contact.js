document.addEventListener('DOMContentLoaded', function() {
    // Function to show the notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerText = message;
      
        document.body.appendChild(notification);
      
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 500); // This timeout should match the transition duration in the CSS
        }, 3000); // Display the notification for 3 seconds
    }

    const contactForm = document.querySelector('.contact form[name="enq"]');
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Prevent the default form submission behavior

        const name = contactForm.querySelector('input[name="name"]').value;
        const email = contactForm.querySelector('input[name="email"]').value;
        const subject = contactForm.querySelector('input[name="subject"]').value;
        const message = contactForm.querySelector('textarea[name="message"]').value;

        // You can add form validation logic here if needed

        showNotification('Contact form submitted!');
    });
});
