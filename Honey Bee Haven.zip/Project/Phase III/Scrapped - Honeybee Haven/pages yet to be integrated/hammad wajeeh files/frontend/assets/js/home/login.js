document.addEventListener('DOMContentLoaded', function() {

    // Function to show the notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerText = message;
  
        document.body.appendChild(notification);
  
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 500); // This timeout should match the transition duration in the CSS
        }, 3000); // Display the notification for 3 seconds
    }
  
    // Capturing and saving the login form data
    const loginForm = document.querySelector('.login-form form');
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault(); 
  
        const email = loginForm.querySelector('input[type="text"]').value;
        const password = loginForm.querySelector('input[type="password"]').value;
  
        // Variables 'email' and 'password' now hold the user's login input.
        // You can now send this data to your backend.
  
        showNotification('Login form submitted!');
    });
  
  

  });
  