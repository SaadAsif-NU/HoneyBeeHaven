document.addEventListener('DOMContentLoaded', function() {

    // // Function to show the notification
    // function showNotification(message) {
    //     const notification = document.createElement('div');
    //     notification.className = 'notification';
    //     notification.innerText = message;
  
    //     document.body.appendChild(notification);
  
    //     setTimeout(() => {
    //         notification.style.opacity = '0';
    //         setTimeout(() => {
    //             notification.remove();
    //         }, 500); // This timeout should match the transition duration in the CSS
    //     }, 3000); // Display the notification for 3 seconds
    // }
  
  
  
   // Capturing and saving the signup form data
    const signupForm = document.querySelector('.signup-form form');
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault(); 
  
        const name = signupForm.querySelector('.input-box:nth-child(1) input[type="text"]').value;
        const Business_name = signupForm.querySelector('.input-box:nth-child(2) input[type="text"]').value;
        const contact = signupForm.querySelector('.input-box:nth-child(3) input[type="text"]').value;
        const email = signupForm.querySelector('.input-box:nth-child(4) input[type="text"]').value;
        const password = signupForm.querySelector('.input-box:nth-child(5) input[type="password"]').value;
        const acc_Number = signupForm.querySelector('.input-box:nth-child(6) input[type="text"]').value;
        const target_keywords = signupForm.querySelector('.input-box:nth-child(7) input[type="text"]').value;
        const address = signupForm.querySelector('.input-box:nth-child(8) input[type="text"]').value;
        const description = signupForm.querySelector('.input-box:nth-child(9) input[type="text"]').value;
      
        // console.log(selectedGender); // This will log the selected gender (e.g., "male", "female", or "other")
        
        // Now, you can use the variable selectedGender as needed.
    });
        // Variables 'name', 'email', and 'password' now hold the user's signup input.
        // You can now send this data to your backend.
  
        showNotification('Signup form submitted!');
    });
  
  